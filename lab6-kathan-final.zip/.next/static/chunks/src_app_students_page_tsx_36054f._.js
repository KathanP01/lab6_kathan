(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_students_page_tsx_36054f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_students_page_tsx_36054f._.js",
  "chunks": [
    "static/chunks/_e44dee._.js"
  ],
  "source": "dynamic"
});
