export interface Student {
    _id?: string;
    name: string;
    email: string;
    age: number;
  }
  